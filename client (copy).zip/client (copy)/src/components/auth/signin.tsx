import React from "react";


const Signin: React.FC = () => {
    return (<div>
        <h1>Sign In</h1>
    </div>);
};

export default Signin;
