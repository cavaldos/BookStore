import React from "react";

const Signup: React.FC = () => {
  return (
    <div>
      <h1>Sign up</h1>
    </div>
  );
};

export default Signup;
