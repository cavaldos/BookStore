// NotFoundComponent.tsx

import React from "react";

export const NotFoundComponent: React.FC = () => {
  return <div>Not Found</div>;
};
