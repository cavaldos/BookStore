import React from "react";

const Home: React.FC = () => {
  return (
    <>
      <h1>Home</h1>
      <div></div>
    </>
  );
};

export default Home;
