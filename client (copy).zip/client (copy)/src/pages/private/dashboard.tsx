import React from "react";

const DashBoard: React.FC = () => {
  return (
    <>
      <h1>Dashboard</h1>
      <div></div>
    </>
  );
};

export default DashBoard;
