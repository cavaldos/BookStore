VITE_API_URL =http://localhost:3000
VITE_FAKE_API =https://fakestoreapi.com/products
VITE_FAKE_URL =https://fakestoreapi.com